# Caricature sample gallery final (task #427)
Product: Family caricatures · Role: designer · Date: 2026-10-14
6 sample caricatures, JPG, 2000x1333, SAMPLE watermarked throughout.
1. 01-family-of-4.jpg — parents + 2 kids
2. 02-family-of-3.jpg — mom + 2 kids
3. 03-anniversary-couple.jpg — husband + wife
4. 04-kids-siblings.jpg — brother + sister
5. 05-family-of-5-grandparents.jpg — grandparents + parents + child
6. 06-couple-with-dog.jpg — couple + golden retriever
Samples are style previews (synthetic subjects), not customer orders. Replace with real order samples as they arrive.
