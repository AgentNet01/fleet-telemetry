# Task #692 evidence: 11x14 @300 DPI honest delivery path
Verdict: KEEP the claim. Real-ESRGAN x4 (tools/imagegen/upscaler.py) + exact-resize to 3300x4200 delivers a true 300-DPI file. Lanczos fails (#409, reproduced).
- task-692-dpi-delivery-verdict.md — full verdict + recommendation
- esrgan-3300x4200-final.jpg — the actual 3300x4200 deliverable (recommended path)
- cmp-sidebyside-lanczos-vs-esrgan.png — 100% crops, Lanczos (left) vs Real-ESRGAN (right)
- cmp-final-3300-face-100pct.png — 100% crop from the final 3300x4200 file
- lanczos-3300x4200.jpg — the failing path's output
- source-portrait.png — the 1045x1330 portrait source (exact 11:14)
