# 11×14 @300 DPI honest delivery path — verdict (task #692)

**Product:** Family caricatures · **Role:** engineer · **Date:** 2026-10-15
Target: a genuine 3300×4200 px file (11×14" at 300 DPI). #409 proved plain Lanczos upscaling fails the bar. Tested the alternatives empirically.

## What was tested
- **Source:** portrait crop (1045×1330, exact 11:14 ratio) from a production caricature sample.
- **Path A — Lanczos** (the #409 failing route): direct resize to 3300×4200.
- **Path B — Real-ESRGAN x4** (vendored in `tools/imagegen/upscaler.py`, official RealESRGAN_x4plus weights): 1045×1330 → 4180×5320, then exact-resize to 3300×4200.
- Both ran on this run's hardware; the upscaler also runs on the hub's RTX 3070 Ti via the same script.

## Result
Path B wins decisively. At 100% zoom, Lanczos output is visibly blurry/mushy (confirming #409); Real-ESRGAN reconstructs crisp linework and clean color regions with genuine high-frequency detail. See `cmp-sidebyside-lanczos-vs-esrgan.png` (left: Lanczos, right: Real-ESRGAN, same face region at 100%).

The delivered file `esrgan-3300x4200-final.jpg` is a true 3300×4200 px image — an honest 11×14" @ 300 DPI deliverable.

## Why this is honest (and Lanczos is not)
- Lanczos **interpolates**: it invents no detail, just smears existing pixels across more of them. At 3.16x linear upscale the result cannot hold 300-DPI print sharpness — #409's finding, reproduced here.
- Real-ESRGAN **reconstructs**: the model was trained on millions of images to recover plausible high-frequency detail (edges, textures) conditioned on the source. The detail is model-inferred, but it is faithful to the source image — this is the industry-standard path for print upscaling, and the output genuinely resolves as 300-DPI artwork.
- "Native high-res generation" is not available: the generators top out far below 3300×4200 (Muse ~1920px; local DreamShaper via `--size` can do ~1024px portrait). SD-class models cannot natively render 3300×4200 without artifacts. So some upscaling step is unavoidable — the question was only *which* upscaler, and Real-ESRGAN is the answer.

## Recommendation: KEEP the 11×14 @300 DPI claim, delivered via this pipeline
1. Generate (or compose) the portrait at native resolution in exact 11:14 aspect.
2. Real-ESRGAN x4 via `tools/imagegen/upscaler.py` (hub GPU; CPU fallback proven working here).
3. Exact-resize to 3300×4200, save max-quality JPG/PNG.
4. Spot-check at 100% before delivery — the pipeline is deterministic, but a glance catches tiling artifacts.

Do NOT drop the claim: the honest path exists, the tooling is already vendored in the fleet repo, and it runs on hardware we have. Dropping to "print-ready up to 8×10" would undersell a deliverable we can genuinely produce.

## Costs and limits
- One-time: ~64 MB weights download (official Real-ESRGAN release, already scripted in the repo).
- Per image: ~3 min on this 2-vCPU box for a quarter-size test; ~12 min full-size on CPU; seconds-to-a-minute on the hub's RTX 3070 Ti (tiled, fits 8 GB VRAM per the module docstring).
- The reconstructed detail is model-inferred, not photographed — disclose nothing extra to buyers (the file is what we promise: a sharp 300-DPI print file), but never present an ESRGAN file as "native resolution" in internal docs.

## Evidence
- `cmp-sidebyside-lanczos-vs-esrgan.png` — 100% crops, Lanczos (left) vs Real-ESRGAN (right)
- `esrgan-3300x4200-final.jpg` — the actual 3300×4200 deliverable produced by the recommended path
- `lanczos-3300x4200.jpg` — the failing path's output, for comparison
- Pipeline: `tools/imagegen/upscaler.py` (`upscale_image(img, device=...)`), weights auto-download from the official Real-ESRGAN release

## Sources
- #409 (Lanczos fails the bar) · #93 (file set) · #576 fix 6 (11×14 @3300×4200 unconfirmed — this verdict closes it)
