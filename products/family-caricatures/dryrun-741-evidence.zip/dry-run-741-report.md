# Caricature fulfillment dry-run with timestamps (task #741)

**Product:** Family caricatures · **Role:** engineer · **Date:** 2026-10-15
End-to-end dry-run of a caricature order. No real purchase, no real buyer — synthetic intake photo, simulated approval. Every step timestamped (UTC).

## Timeline (real timestamps)

| Step | Time (UTC) | Elapsed |
|---|---|---|
| t0 — order intake opened | 2026-10-15T06:14:51Z | — |
| t1 — customer photo received | 2026-10-15T06:15:07Z | +16s |
| t2 — caricature generated from photo | 2026-10-15T06:15:43Z | +36s |
| t3 — watermarked proof sent (AI disclosure) | 2026-10-15T06:15:48Z | +5s |
| t4 — buyer approved (simulated) | 2026-10-15T06:15:51Z | +3s |
| t5 — finals delivered (3300×4200) | 2026-10-15T06:26:43Z | +10m52s |
| **Total** | | **~11m52s** |

The finals step dominates: Real-ESRGAN x4 on a 2-vCPU box. On the hub's RTX 3070 Ti the same step is seconds-to-a-minute (tiled, per the module docstring), which would bring the full run to ~2 minutes.

## What was produced
1. **Photo intake** — `intake-customer-photo` (synthetic family photo, stands in for the buyer's upload; real orders arrive via Etsy Message per #90).
2. **Muse generation** — `caricature-from-photo` (caricature drawn from the intake photo, image-to-image).
3. **Proof** — `proof-watermarked.jpg` (2000px, PROOF watermarked throughout, footer: "AI-assisted digital artwork — custom-made from your photo. Not final until you approve.").
4. **Finals** — `finals-11x14-300dpi.jpg`, exact 3300×4200 px via the #692 pipeline (portrait 11:14 crop → Real-ESRGAN x4 → exact resize). No PROOF watermark, no disclosure footer on the deliverable.

## Turnaround honesty check
- PM-confirmed terms (#467/#231): proof within 3 business days, 2 free revision rounds (3 BD each), finals within 24h of approval.
- This dry-run's machine time (~12 min worst-case on weak hardware) fits comfortably inside those terms with massive headroom. The pipeline does not threaten the 3-BD proof promise even with a revision round.
- No step required a real person, a purchase, or account access.

## Files
All in this package: intake photo, generated caricature, watermarked proof, 3300×4200 finals, six timestamp files, this doc.
