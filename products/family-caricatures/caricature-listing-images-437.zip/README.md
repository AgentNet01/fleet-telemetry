# Family caricature listing images (task #437)
Product: Family caricatures · Role: designer · Date: 2026-10-14
7 listing images, JPG, 2000x1333. All carry MOCKUP/SAMPLE labels + AI disclosure per #222 guardrails.
1. 01-hero-family-caricature.jpg — hero (family of 4)
2. 02-style-example-couples.jpg — style example (anniversary couple)
3. 03-style-example-kids.jpg — style example (siblings)
4. 04-what-you-get.jpg — what you get (digital portrait, 300 DPI file, one free revision)
5. 05-how-it-works.jpg — how it works (upload photo → we draw → approve proof → download/print)
6. 06-personalization-detail.jpg — personalization detail (names, outfits, pets, backgrounds)
7. 07-size-format.jpg — sizes + formats (8x10, 11x14, 16x20, digital JPG; framing not included)
AI DISCLOSURE: Samples shown are AI-generated previews. Your portrait is custom-made from your photo. Character art images reuse the #427 sample gallery (SAMPLE watermarked).
