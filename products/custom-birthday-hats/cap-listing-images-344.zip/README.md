# Cap listing images: embroidered birthday cap (task #344)
Product: Custom birthday hats · Role: designer · Date: 2026-10-14
Status: PREVIEW IMAGES for the cap option — the PM has NOT decided the hat type (cone vs cap vs crown; #328 informs, does not decide). These images are ready to use IF the PM picks the cap; they do not claim a decision.

Files (all PNG, 2000px long edge):
1. 01-hero-black-cap-sophia-21.png — hero: black dad cap, gold SOPHIA 21 embroidery, balloon + star
2. 02-pink-cap-emma-16.png — color variant: blush pink cap, rose-gold EMMA 16, cupcake + star
3. 03-back-adjustable-strap.png — back view: adjustable strap, EST. 2005 back embroidery (size/what-you-get)
4. 04-lifestyle-flat-lay.png — lifestyle: cap with balloons, confetti, cake, gift box
5. 05-how-to-personalize.png — how-to-personalize: pick design → send name+age → approve proof → we embroider

Notes: mockups generated for preview (not photographs of a physical sample). Personalization is embroidered name + age TEXT — no photos (per #276 embroidery constraints). Replace with real sample photos after the first production run.
